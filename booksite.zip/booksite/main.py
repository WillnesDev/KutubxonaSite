from flask import Flask, render_template, request
import json

app = Flask(__name__)

@app.route('/')
def index():
    lang = request.args.get('lang', 'uz')
    return render_template('index.html', lang=lang)

@app.route('/search')
def search():
    query = request.args.get('query', '').lower()
    lang = request.args.get('lang', 'uz')

    with open('books.json', 'r', encoding='utf-8') as f:
        books = json.load(f)

    results = [book for book in books if query in book['title'].lower()]

    return render_template('results.html', results=results, lang=lang)

# Yangi route: mavjud kitoblar
@app.route('/books')
def all_books():
    with open('books.json', 'r', encoding='utf-8') as f:
        books = json.load(f)
    return render_template('all_books.html', books=books)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)